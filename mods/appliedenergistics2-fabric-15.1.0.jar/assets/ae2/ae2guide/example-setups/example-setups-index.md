---
navigation:
  title: Example Setups
  position: 40
---

# Example Setups

<SubPages />