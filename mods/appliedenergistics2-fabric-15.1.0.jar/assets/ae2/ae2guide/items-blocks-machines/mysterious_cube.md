---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Mysterious Cube
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# The Mysterious Cube

<BlockImage id="mysterious_cube" scale="8" />

Remember when you had to find a bunch of meteors to find all the presses? No more! Now meteorites come with a Mysterious Cube.

I wonder what happens when you break it (without silk touch)...

You can also make a replica, the Not So Mysterious Cube

## Recipe

<RecipeFor id="not_so_mysterious_cube" />
