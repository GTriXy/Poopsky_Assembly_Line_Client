---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Pearl
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Fluix Pearl

<ItemImage id="fluix_pearl" scale="4" />

An ender pearl coated in <ItemLink id="fluix_crystal" />, used in the production of
several AE2 components.

## Recipe

<RecipeFor id="fluix_pearl" />
