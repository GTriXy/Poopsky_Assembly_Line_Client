---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Sky Stone Tank
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# The Sky Stone Tank

<BlockImage id="sky_stone_tank" scale="8" />

It's a fluid tank that stores 16 buckets of fluid. Does not retain its contents when picked up. Not much else to say.

## Recipe

<RecipeFor id="sky_stone_tank" />
